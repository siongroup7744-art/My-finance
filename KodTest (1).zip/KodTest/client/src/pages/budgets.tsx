import { useState } from "react";
import { useFinance } from "@/lib/finance-context";
import { translations, currencies } from "@/lib/translations";
import { isSameMonth, parseISO, format } from "date-fns";
import { expenseCategories } from "@/lib/categories";
import { Icon } from "@/components/icon-mapper";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function Budgets() {
  const { language, budgets, setBudgets, transactions, customCategories, currentMonth, themeKey } = useFinance();
  const t = translations[language];
  const currency = currencies[language];
  const borderClass = themeKey === 'light' ? 'border-gray-300' : 'border-white/5';
  const bgClass = themeKey === 'light' ? 'bg-gray-50' : 'bg-white/5';
  
  const chartGridColor = themeKey === 'light' ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.1)';
  const chartAxisColor = themeKey === 'light' ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.5)';
  const chartTextColor = themeKey === 'light' ? '#1F2937' : 'rgba(255,255,255,0.5)';
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<string | null>(null);
  const [budgetAmount, setBudgetAmount] = useState("");
  const [categoryName, setCategoryName] = useState("");

  const monthKey = format(currentMonth, 'yyyy-MM');
  const currentMonthBudgets = budgets[monthKey] || {};

  const defaultCategories = expenseCategories[language];
  
  // Combine default and custom expense categories
  const categories = {
    ...defaultCategories,
    ...Object.fromEntries(
      customCategories
        .filter(cat => !cat.income) // Only expense categories
        .map(cat => [cat.key, cat])
    )
  };

  const handleSaveBudget = () => {
    if (!editingCat) return;
    const amount = parseFloat(budgetAmount) || 0;
    setBudgets(prev => ({ 
      ...prev, 
      [monthKey]: { ...prev[monthKey], [editingCat]: amount } 
    }));
    setBudgetAmount("");
    setEditingCat(null);
    setIsAddOpen(false);
  };

  const handleEditBudget = (catKey: string) => {
    setEditingCat(catKey);
    setBudgetAmount((currentMonthBudgets[catKey] || 0).toString());
    setCategoryName(categories[catKey]?.name || "");
    setIsAddOpen(true);
  };

  // Calculate spent per category (this month)
  const spentByCategory: Record<string, number> = {};
  transactions.forEach(tx => {
    if (!tx.income && isSameMonth(parseISO(tx.date), currentMonth)) {
      spentByCategory[tx.categoryKey] = (spentByCategory[tx.categoryKey] || 0) + tx.amount;
    }
  });

  // Chart data for budgets
  const chartData = Object.entries(categories)
    .filter(([key]) => currentMonthBudgets[key] || spentByCategory[key])
    .map(([key, cat]) => ({
      name: cat.name.substring(0, 8),
      spent: spentByCategory[key] || 0,
      budget: currentMonthBudgets[key] || 0
    }))
    .sort((a, b) => (b.spent + b.budget) - (a.spent + a.budget));

  return (
    <div className="p-6 pt-12 space-y-6 pb-24">
      <div className="flex items-center">
        <h1 className="text-2xl font-bold">{t.budgets}</h1>
      </div>
      <p className="text-xs opacity-60">{t.clickToSetBudget}</p>

      {/* Bar Chart */}
      {chartData.length > 0 && (
        <div className={`${bgClass} border ${borderClass} rounded-2xl p-4`}>
          <h3 className="text-sm font-bold mb-4 opacity-70">{t.budgetOverview}</h3>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartGridColor} />
                <XAxis dataKey="name" stroke={chartAxisColor} style={{ fontSize: '12px', fill: chartTextColor }} />
                <YAxis stroke={chartAxisColor} style={{ fontSize: '12px', fill: chartTextColor }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: themeKey === 'light' ? '#FFFFFF' : 'rgba(0,0,0,0.8)', border: themeKey === 'light' ? '1px solid #E5E7EB' : '1px solid rgba(255,255,255,0.2)', borderRadius: '8px', color: themeKey === 'light' ? '#1F2937' : '#FFF' }}
                  formatter={(value: any) => value.toFixed(2)}
                />
                <Legend wrapperStyle={{ color: chartTextColor }} />
                <Bar dataKey="spent" fill="#ef4444" name={t.spent} />
                <Bar dataKey="budget" fill="#10b981" name={t.budget} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
      
      <div className="grid gap-4">
        {Object.entries(categories).map(([key, cat]) => {
          const budgetLimit = currentMonthBudgets[key] || 0;
          const spent = spentByCategory[key] || 0;
          const percentage = budgetLimit > 0 ? (spent / budgetLimit) * 100 : 0;
          
          return (
            <div
              key={key}
              onClick={() => handleEditBudget(key)}
              className={`p-4 rounded-2xl ${bgClass} border ${borderClass} hover:${themeKey === 'light' ? 'bg-gray-100' : 'bg-white/10'} transition-colors text-left cursor-pointer`}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: cat.color }}>
                  <Icon name={cat.icon} size={16} color="white" />
                </div>
                <span className="font-medium flex-1">{cat.name}</span>
                {budgetLimit > 0 && <span className="text-xs opacity-70">{spent.toFixed(2)}/{budgetLimit.toFixed(2)}</span>}
              </div>
              <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                <div 
                  className={cn("h-full transition-all", percentage > 100 ? "bg-red-500" : percentage > 80 ? "bg-yellow-500" : "bg-green-500")}
                  style={{ width: `${Math.min(percentage, 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-xs mt-2 opacity-60">
                <span>{spent.toFixed(2)} {currency}</span>
                <span>{budgetLimit > 0 ? `${budgetLimit.toFixed(2)} ${currency}` : "Tap to add"}</span>
              </div>
            </div>
          );
        })}
      </div>

      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent className="sm:max-w-[425px] border-none text-white" style={{ backgroundColor: 'var(--finance-card)' }}>
          <DialogHeader>
            <DialogTitle style={{ color: 'var(--finance-text)' }}>
              {editingCat ? categoryName : t.budgets}
            </DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            <div className="space-y-2">
              <label className="text-xs opacity-70">{t.setBudgetFor} {categoryName}</label>
              <Input
                type="number"
                step="0.01"
                value={budgetAmount}
                onChange={(e) => setBudgetAmount(e.target.value)}
                placeholder="0.00"
                className="text-center text-2xl border-none bg-black/20"
                style={{ color: 'var(--finance-text)' }}
                autoFocus
              />
            </div>

            <Button 
              onClick={handleSaveBudget} 
              className="w-full h-12 rounded-xl text-lg font-semibold hover:opacity-90 transition"
              style={{ backgroundColor: 'var(--finance-accent)', color: '#fff' }}
            >
              {t.saveBudget}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
