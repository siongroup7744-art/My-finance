import { useFinance } from "@/lib/finance-context";
import { translations, currencies } from "@/lib/translations";
import { expenseCategories, incomeCategories } from "@/lib/categories";
import { Icon } from "@/components/icon-mapper";
import { useState, useMemo } from "react";
import AddCategoryDialog from "@/components/add-category-dialog";
import { cn } from "@/lib/utils";
import { parseISO, startOfMonth, endOfMonth, isWithinInterval } from "date-fns";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function Categories() {
  const { language, customCategories, deleteCategory, transactions, themeKey, currentMonth, yearMode, selectedYear } = useFinance();
  const t = translations[language];
  const currency = currencies[language];
  const borderClass = themeKey === 'light' ? 'border-gray-300' : 'border-white/5';
  const bgClass = themeKey === 'light' ? 'bg-gray-50' : 'bg-white/5';
  
  const chartGridColor = themeKey === 'light' ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.1)';
  const chartAxisColor = themeKey === 'light' ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.5)';
  const chartTextColor = themeKey === 'light' ? '#1F2937' : 'rgba(255,255,255,0.5)';
  
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [filter, setFilter] = useState<'expense' | 'income'>('expense');
  const [editingCat, setEditingCat] = useState<any>(undefined);
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  const defaultCats = filter === 'income' ? incomeCategories[language] : expenseCategories[language];
  
  // Filter custom categories
  const customCats = customCategories.filter(c => !!c.income === (filter === 'income'));

  // Filter transactions by period (year or month)
  const periodTransactions = useMemo(() => {
    if (yearMode) {
      const yearStart = new Date(selectedYear, 0, 1);
      const yearEnd = new Date(selectedYear, 11, 31);
      return transactions.filter(tx => 
        isWithinInterval(parseISO(tx.date), { start: yearStart, end: yearEnd })
      );
    } else {
      const monthStart = startOfMonth(currentMonth);
      const monthEnd = endOfMonth(currentMonth);
      return transactions.filter(tx => 
        isWithinInterval(parseISO(tx.date), { start: monthStart, end: monthEnd })
      );
    }
  }, [transactions, yearMode, selectedYear, currentMonth]);

  // Calculate spending by category (period filtered for both chart and list)
  const spendingByCategory: Record<string, number> = {};
  periodTransactions.forEach(tx => {
    if (!tx.income === (filter === 'expense')) {
      spendingByCategory[tx.categoryKey] = (spendingByCategory[tx.categoryKey] || 0) + tx.amount;
    }
  });

  // Chart data for categories (uses period-filtered transactions)
  const allCats = { ...defaultCats };
  customCats.forEach(c => {
    allCats[c.key] = c;
  });

  const chartData = Object.entries(allCats)
    .map(([key, cat]) => ({
      name: cat.name.substring(0, 10),
      amount: spendingByCategory[key] || 0,
      fill: cat.color
    }))
    .filter(d => d.amount > 0)
    .sort((a, b) => b.amount - a.amount);

  const handleEdit = (cat: any) => {
    setEditingCat(cat);
    setIsAddOpen(true);
  };

  const handleOpenAdd = () => {
    setEditingCat(undefined);
    setIsAddOpen(true);
  };

  return (
    <div className="p-6 pt-12 space-y-6 pb-24">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t.categories}</h1>
        <button 
          onClick={handleOpenAdd}
          className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
        >
          <Icon name="plus" />
        </button>
      </div>

      <div className="flex gap-4 border-b border-white/10 pb-4">
        <button 
          onClick={() => setFilter('expense')}
          className={cn("pb-2 border-b-2 transition-colors px-2", filter === 'expense' ? "border-red-500 text-red-500" : "border-transparent opacity-50")}
        >
          {t.expenses}
        </button>
        <button 
          onClick={() => setFilter('income')}
          className={cn("pb-2 border-b-2 transition-colors px-2", filter === 'income' ? "border-green-500 text-green-500" : "border-transparent opacity-50")}
        >
          {t.incomeTitle}
        </button>
      </div>

      {/* Bar Chart */}
      {chartData.length > 0 && (
        <div className={`${bgClass} border ${borderClass} rounded-2xl p-4`}>
          <h3 className="text-sm font-bold mb-4 opacity-70">{t.spendingByCategory}</h3>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartGridColor} />
                <XAxis dataKey="name" stroke={chartAxisColor} style={{ fontSize: '12px', fill: chartTextColor }} />
                <YAxis stroke={chartAxisColor} style={{ fontSize: '12px', fill: chartTextColor }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: themeKey === 'light' ? '#FFFFFF' : 'rgba(0,0,0,0.8)', border: themeKey === 'light' ? '1px solid #E5E7EB' : '1px solid rgba(255,255,255,0.2)', borderRadius: '8px', color: themeKey === 'light' ? '#1F2937' : '#FFF' }}
                  formatter={(value: any) => [value.toFixed(2), 'Amount']}
                />
                <Bar dataKey="amount" fill="#8884d8" name="Amount" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
      
      {/* Sort Buttons */}
      <div className="flex justify-center gap-2">
        <button
          onClick={() => setSortOrder('desc')}
          className={cn(
            "p-2 rounded-lg transition-colors",
            sortOrder === 'desc' 
              ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg" 
              : "bg-white/5 opacity-50 hover:opacity-80"
          )}
          title="Highest to lowest"
        >
          <Icon name="trending-down" size={18} />
        </button>
        <button
          onClick={() => setSortOrder('asc')}
          className={cn(
            "p-2 rounded-lg transition-colors",
            sortOrder === 'asc' 
              ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg" 
              : "bg-white/5 opacity-50 hover:opacity-80"
          )}
          title="Lowest to highest"
        >
          <Icon name="trending-up" size={18} />
        </button>
      </div>
      
      <div className="grid gap-3">
        {/* Sorted Categories */}
        {Object.entries(spendingByCategory)
          .sort((a, b) => sortOrder === 'desc' ? b[1] - a[1] : a[1] - b[1])
          .filter(([key]) => {
            const isCustm = customCats.some(c => c.key === key);
            return isCustm || Object.keys(defaultCats).includes(key);
          })
          .map(([key, amount]) => {
            const cat = allCats[key];
            const isCustm = customCats.some(c => c.key === key);
            
            if (!cat) return null;
            
            if (isCustm) {
              const customCat = customCats.find(c => c.key === key);
              if (!customCat) return null;
              return (
                <DropdownMenu key={customCat.key}>
                  <DropdownMenuTrigger asChild>
                    <div className={`flex items-center justify-between p-4 rounded-2xl ${bgClass} border ${borderClass} active:${themeKey === 'light' ? 'bg-gray-100' : 'bg-white/10'} transition-colors cursor-pointer`}>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: customCat.color }}>
                          <Icon name={customCat.icon} size={20} color="white" />
                        </div>
                        <div className="flex flex-col">
                          <span className="font-medium">{customCat.name}</span>
                          <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full opacity-70 w-fit">Custom</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-semibold">
                          {currency}{amount.toFixed(2)}
                        </span>
                        <Icon name="more-horizontal" size={16} className="opacity-50" />
                      </div>
                    </div>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-40 bg-zinc-900 border-zinc-800 text-white">
                      <DropdownMenuItem onClick={() => handleEdit(customCat)} className="cursor-pointer focus:bg-zinc-800 focus:text-white">
                        <Icon name="edit" size={16} className="mr-2" /> {t.editTransaction}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => deleteCategory(customCat.key)} className="text-red-500 focus:text-red-500 focus:bg-red-900/20 cursor-pointer">
                        <Icon name="trash" size={16} className="mr-2" /> {t.delete}
                      </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              );
            } else {
              return (
                <div key={key} className={`flex items-center justify-between p-4 rounded-2xl ${bgClass} border ${borderClass} opacity-80`}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: cat.color }}>
                      <Icon name={cat.icon} size={20} color="white" />
                    </div>
                    <span className="font-medium">{cat.name}</span>
                  </div>
                  <span className="text-sm font-semibold">
                    {currency}{amount.toFixed(2)}
                  </span>
                </div>
              );
            }
          })}
        
        {/* Total Sum Footer */}
        {Object.keys(spendingByCategory).length > 0 && (
          <div className={`flex items-center justify-between p-4 rounded-2xl ${bgClass} border ${borderClass} border-2 border-opacity-50 mt-4`}>
            <span className="font-bold text-base opacity-70">{filter === 'income' ? t.incomeTitle : t.expenses} {t.total}</span>
            <span className="text-lg font-bold bg-gradient-to-r from-blue-400 to-blue-500 bg-clip-text text-transparent">
              {currency}{Object.values(spendingByCategory).reduce((sum, val) => sum + val, 0).toFixed(2)}
            </span>
          </div>
        )}
      </div>

      <AddCategoryDialog open={isAddOpen} onOpenChange={setIsAddOpen} editCategory={editingCat} />
    </div>
  );
}
