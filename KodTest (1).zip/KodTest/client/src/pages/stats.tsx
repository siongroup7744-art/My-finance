import { useFinance } from "@/lib/finance-context";
import { translations, currencies } from "@/lib/translations";
import { expenseCategories, incomeCategories } from "@/lib/categories";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line, Legend } from "recharts";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, parseISO, isSameDay, subMonths } from "date-fns";
import { bg, enUS, ru } from "date-fns/locale";
import { useMemo } from "react";
import { Icon } from "@/components/icon-mapper";

export default function Stats() {
  const { transactions, currentMonth, language, themeKey } = useFinance();
  const t = translations[language];
  const currency = currencies[language];
  const locale = language === 'bg' ? bg : language === 'ru' ? ru : enUS;
  const borderClass = themeKey === 'light' ? 'border-gray-300' : 'border-white/5';
  const bgClass = themeKey === 'light' ? 'bg-gray-50' : 'bg-white/5';
  
  const chartGridColor = themeKey === 'light' ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.1)';
  const chartAxisColor = themeKey === 'light' ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.3)';
  const chartTextColor = themeKey === 'light' ? '#1F2937' : 'rgba(255,255,255,0.3)';

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  
  const monthTx = useMemo(() => transactions.filter(tx => 
    !tx.income && 
    parseISO(tx.date) >= monthStart && 
    parseISO(tx.date) <= monthEnd
  ), [transactions, monthStart, monthEnd]);

  const { categoryStats, total, dailyData, avgDaily, maxDaily } = useMemo(() => {
    const cats = Object.entries(expenseCategories[language]).map(([key, cat]) => {
      const amount = monthTx
        .filter(t => t.categoryKey === key)
        .reduce((sum, t) => sum + t.amount, 0);
      return { key, name: cat.name, color: cat.color, amount };
    }).filter(c => c.amount > 0).sort((a, b) => b.amount - a.amount);

    const tot = cats.reduce((sum, c) => sum + c.amount, 0);

    const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
    const daily = days.map(day => {
      const amount = monthTx
        .filter(t => isSameDay(parseISO(t.date), day))
        .reduce((sum, t) => sum + t.amount, 0);
      return { day: format(day, 'd'), amount };
    });

    const avg = daily.length > 0 ? tot / daily.length : 0;
    const max = daily.length > 0 ? Math.max(...daily.map(d => d.amount)) : 0;

    return { categoryStats: cats, total: tot, dailyData: daily, avgDaily: avg, maxDaily: max };
  }, [monthTx, language, monthStart, monthEnd]);

  const monthlyStats = useMemo(() => {
    const stats = [];
    for (let i = 5; i >= 0; i--) {
      const month = subMonths(currentMonth, i);
      const start = startOfMonth(month);
      const end = endOfMonth(month);
      const expense = transactions.filter(tx => !tx.income && parseISO(tx.date) >= start && parseISO(tx.date) <= end).reduce((sum, t) => sum + t.amount, 0);
      const income = transactions.filter(tx => tx.income && parseISO(tx.date) >= start && parseISO(tx.date) <= end).reduce((sum, t) => sum + t.amount, 0);
      stats.push({
        month: format(month, 'MMM', { locale }),
        expense,
        income,
        balance: income - expense
      });
    }
    return stats;
  }, [transactions, currentMonth, locale]);

  const topCategories = useMemo(() => categoryStats.slice(0, 5), [categoryStats]);

  return (
    <div className="p-6 pt-12 space-y-6 pb-24">
      <h1 className="text-2xl font-bold mb-6">{t.stats}</h1>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 rounded-2xl bg-gradient-to-br from-red-500/20 to-red-600/10 border border-red-500/30">
          <p className="text-xs opacity-70 mb-1">{t.totalExpenses}</p>
          <h3 className="text-2xl font-bold text-red-400">{total.toFixed(0)}</h3>
          <p className="text-xs opacity-50 mt-1">{t.avgDaily}: {avgDaily.toFixed(1)}</p>
        </div>
        <div className="p-4 rounded-2xl bg-gradient-to-br from-orange-500/20 to-orange-600/10 border border-orange-500/30">
          <p className="text-xs opacity-70 mb-1">{t.peak}</p>
          <h3 className="text-2xl font-bold text-orange-400">{maxDaily.toFixed(0)}</h3>
          <p className="text-xs opacity-50 mt-1">{dailyData.length} дни</p>
        </div>
      </div>

      {/* Monthly Trend */}
      <div className={`p-4 rounded-2xl ${bgClass} border ${borderClass}`}>
        <h3 className="text-sm font-bold opacity-70 mb-4">{t.trendTitle}</h3>
        <div className="h-[200px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={monthlyStats}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartGridColor} />
              <XAxis dataKey="month" stroke={chartAxisColor} style={{ fontSize: '11px', fill: chartTextColor }} />
              <YAxis stroke={chartAxisColor} style={{ fontSize: '11px', fill: chartTextColor }} />
              <Tooltip contentStyle={{ backgroundColor: themeKey === 'light' ? '#FFFFFF' : 'rgba(0,0,0,0.9)', border: themeKey === 'light' ? '1px solid #E5E7EB' : '1px solid rgba(255,255,255,0.2)', color: themeKey === 'light' ? '#1F2937' : '#FFF' }} />
              <Legend wrapperStyle={{ color: chartTextColor }} />
              <Line type="monotone" dataKey="expense" stroke="#ef4444" strokeWidth={2} dot={{ r: 2 }} />
              <Line type="monotone" dataKey="income" stroke="#10b981" strokeWidth={2} dot={{ r: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Daily Breakdown */}
      <div className={`p-4 rounded-2xl ${bgClass} border ${borderClass}`}>
        <h3 className="text-sm font-bold opacity-70 mb-4">{t.dailyBreakdown}</h3>
        <div className="h-[180px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={dailyData}>
              <XAxis dataKey="day" stroke={chartAxisColor} fontSize={9} tickLine={false} style={{ fill: chartTextColor }} />
              <Tooltip contentStyle={{ backgroundColor: themeKey === 'light' ? '#FFFFFF' : '#1a1a1a', border: themeKey === 'light' ? '1px solid #E5E7EB' : 'none', borderRadius: '6px', color: themeKey === 'light' ? '#1F2937' : '#FFF' }} />
              <Bar dataKey="amount" fill="var(--finance-accent)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold opacity-70">{t.topCategories}</h3>
        {categoryStats.map(stat => (
          <div key={stat.key} className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: stat.color }} />
                <span className="font-medium">{stat.name}</span>
              </span>
              <span className="font-bold">{stat.amount.toFixed(0)} {currency}</span>
            </div>
            <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full rounded-full" 
                style={{ width: `${(stat.amount / total) * 100}%`, backgroundColor: stat.color }} 
              />
            </div>
          </div>
        ))}
      </div>

      {/* Pie Chart */}
      {categoryStats.length > 0 && (
        <div className={`p-4 rounded-2xl ${bgClass} border ${borderClass}`}>
          <h3 className="text-sm font-bold opacity-70 mb-4">{t.distribution}</h3>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryStats}
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={3}
                  dataKey="amount"
                  stroke="none"
                >
                  {categoryStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Insights */}
      <div className={`p-4 rounded-2xl ${bgClass} border ${themeKey === 'light' ? 'border-gray-300' : 'border-white/10'} pointer-events-none select-none`}>
        <h3 className="text-sm font-bold mb-3 flex items-center gap-2 opacity-70">
          <Icon name="info" size={16} />
          {t.insights}
        </h3>
        <div className="space-y-1.5 text-xs opacity-60">
          {total > 0 && <p>📊 {t.avgDaily}: {avgDaily.toFixed(2)} {currency}</p>}
          {topCategories.length > 0 && <p>🎯 {t.spendingByCategory}: {topCategories[0].name} ({(topCategories[0].amount / total * 100).toFixed(0)}%)</p>}
          {dailyData.length > 0 && <p>📈 {t.peak}: {maxDaily.toFixed(0)} {currency}</p>}
          {monthlyStats.length >= 2 && (
            <p>
              📊 {t.compareMonth}: {Math.abs(monthlyStats[4].expense - monthlyStats[5].expense).toFixed(0)} {currency}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
