import { useFinance } from "@/lib/finance-context";
import { translations, currencies } from "@/lib/translations";
import { expenseCategories, incomeCategories } from "@/lib/categories";
import { format, subMonths, addMonths, isSameMonth, parseISO, startOfMonth, endOfMonth, isWithinInterval } from "date-fns";
import { enUS, bg, ru, de, fr, es, it, pt, pl, nl, sv, da, tr, el, cs, sk, hu, ro } from "date-fns/locale";
import { Icon } from "@/components/icon-mapper";
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { useState, useMemo } from "react";
import AddTransactionDialog from "@/components/add-transaction-dialog";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";

export default function Dashboard() {
  const { 
    currentMonth, setCurrentMonth, 
    language, setLanguage, 
    themeKey, setThemeKey, 
    transactions, setTransactions,
    recurringTx, setRecurringTx,
    budgets, setBudgets,
    customCategories, setCustomCategories,
    exportData, importData,
    deleteTransaction,
    undoLastTransaction,
    lastDeletedTx,
    yearMode, setYearMode,
    selectedYear, setSelectedYear
  } = useFinance();
  
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();
  const [isIncomeModal, setIsIncomeModal] = useState(false);
  const [editingTx, setEditingTx] = useState<any>(undefined);
  
  // Search & Sort State
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc'>('date-desc');
  const [showSearch, setShowSearch] = useState(false);
  const [periodFilter, setPeriodFilter] = useState<'month' | 'week' | 'all' | 'custom'>('month');
  const [customDateFrom, setCustomDateFrom] = useState("");
  const [customDateTo, setCustomDateTo] = useState("");
  const [showMonthPicker, setShowMonthPicker] = useState(false);

  const t = translations[language];
  const currency = currencies[language];
  
  const localeMap: Record<string, any> = {
    bg, en: enUS, ru, de, fr, es, it, pt, pl, nl, sv, da, tr, el, cs, sk, hu, ro
  };
  const locale = localeMap[language] || enUS;

  const monthTransactions = useMemo(() => {
    if (yearMode) {
      const yearStart = new Date(selectedYear, 0, 1);
      const yearEnd = new Date(selectedYear, 11, 31);
      return transactions.filter(tx => 
        isWithinInterval(parseISO(tx.date), { start: yearStart, end: yearEnd })
      );
    } else if (periodFilter === 'month') {
      const monthStart = startOfMonth(currentMonth);
      const monthEnd = endOfMonth(currentMonth);
      return transactions.filter(tx => 
        isWithinInterval(parseISO(tx.date), { start: monthStart, end: monthEnd })
      );
    } else if (periodFilter === 'week') {
      const weekStart = new Date(currentMonth);
      weekStart.setDate(weekStart.getDate() - weekStart.getDay());
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      return transactions.filter(tx => 
        isWithinInterval(parseISO(tx.date), { start: weekStart, end: weekEnd })
      );
    } else if (periodFilter === 'custom' && customDateFrom && customDateTo) {
      const dateFrom = parseISO(customDateFrom);
      const dateTo = parseISO(customDateTo);
      return transactions.filter(tx => 
        isWithinInterval(parseISO(tx.date), { start: dateFrom, end: dateTo })
      );
    }
    return transactions;
  }, [transactions, periodFilter, currentMonth, customDateFrom, customDateTo, yearMode, selectedYear]);

  const displayTransactions = useMemo(() => {
    let result = monthTransactions;
    
    if (searchQuery) {
      const lowerQuery = searchQuery.toLowerCase();
      result = transactions.filter(tx => 
        tx.note?.toLowerCase().includes(lowerQuery) ||
        tx.categoryKey.toLowerCase().includes(lowerQuery) ||
        tx.amount.toString().includes(lowerQuery) ||
        (tx.income ? 'income' : 'expense').includes(lowerQuery)
      );
    }

    return [...result].sort((a, b) => {
      if (sortBy === 'date-desc') {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      } else if (sortBy === 'date-asc') {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      } else if (sortBy === 'amount-desc') {
        return b.amount - a.amount;
      } else {
        return a.amount - b.amount;
      }
    });
  }, [monthTransactions, transactions, searchQuery, sortBy]);

  const { income, expense, balance } = useMemo(() => {
    const inc = monthTransactions.filter(t => t.income).reduce((acc, t) => acc + t.amount, 0);
    const exp = monthTransactions.filter(t => !t.income).reduce((acc, t) => acc + t.amount, 0);
    return { income: inc, expense: exp, balance: inc - exp };
  }, [monthTransactions]);

  const chartData = useMemo(() => {
    const expenseMap: Record<string, number> = {};
    monthTransactions.filter(t => !t.income).forEach(t => {
      expenseMap[t.categoryKey] = (expenseMap[t.categoryKey] || 0) + t.amount;
    });
    return Object.entries(expenseMap)
      .map(([key, value]) => {
        const cat = expenseCategories[language][key];
        return {
          name: cat?.name || key,
          value,
          color: cat?.color || '#999'
        };
      })
      .sort((a, b) => b.value - a.value);
  }, [monthTransactions, language]);

  const incomeChartData = useMemo(() => {
    const incomeMap: Record<string, number> = {};
    monthTransactions.filter(t => t.income).forEach(t => {
      incomeMap[t.categoryKey] = (incomeMap[t.categoryKey] || 0) + t.amount;
    });
    return Object.entries(incomeMap)
      .map(([key, value]) => {
        const cat = incomeCategories[language][key];
        return {
          name: cat?.name || key,
          value,
          color: cat?.color || '#999'
        };
      })
      .sort((a, b) => b.value - a.value);
  }, [monthTransactions, language]);

  const { usageCount, displayQuickCategories } = useMemo(() => {
    const usage: Record<string, number> = {};
    monthTransactions.forEach(tx => {
      usage[tx.categoryKey] = (usage[tx.categoryKey] || 0) + 1;
    });
    const allCats = { ...expenseCategories[language], ...incomeCategories[language] };
    const quickCats = Object.keys(usage)
      .sort((a, b) => usage[b] - usage[a])
      .slice(0, 10);
    return {
      usageCount: usage,
      displayQuickCategories: quickCats.length > 0 
        ? quickCats 
        : ['food', 'coffee', 'transport', 'shopping', 'salary'].filter(k => allCats[k])
    };
  }, [monthTransactions, language]);

  const allCategories = { ...expenseCategories[language], ...incomeCategories[language] };

  const monthlyData = useMemo(() => {
    const data = [];
    for (let i = 5; i >= 0; i--) {
      const month = subMonths(currentMonth, i);
      const start = startOfMonth(month);
      const end = endOfMonth(month);
      const monthExp = transactions.filter(tx => !tx.income && isWithinInterval(parseISO(tx.date), { start, end })).reduce((acc, t) => acc + t.amount, 0);
      const monthInc = transactions.filter(tx => tx.income && isWithinInterval(parseISO(tx.date), { start, end })).reduce((acc, t) => acc + t.amount, 0);
      data.push({
        month: format(month, 'MMM', { locale }),
        expense: monthExp,
        income: monthInc,
        balance: monthInc - monthExp
      });
    }
    return data;
  }, [transactions, currentMonth, locale]);

  const toggleTheme = () => {
    const keys = Object.keys(themes);
    const next = keys[(keys.indexOf(themeKey) + 1) % keys.length];
    setThemeKey(next);
  };

  const openAdd = (cat?: string, income: boolean = false) => {
    setEditingTx(undefined);
    setSelectedCategory(cat);
    setIsIncomeModal(income);
    setIsAddOpen(true);
  };

  const handleEdit = (tx: any) => {
    setEditingTx(tx);
    setIsAddOpen(true);
  };

  const handleMonthSelect = (month: number) => {
    const newDate = new Date(selectedYear, month, 1);
    setCurrentMonth(newDate);
    setYearMode(false);
    setShowMonthPicker(false);
  };

  const handleYearSelect = (year: number) => {
    setSelectedYear(year);
    // Don't close, just mark year
  };

  const handleCurrentYearClick = () => {
    setSelectedYear(currentYear);
    setYearMode(true);
    setShowMonthPicker(false);
  };

  const handleMonthPickerClose = () => {
    if (yearMode) {
      setYearMode(false);
    }
    setShowMonthPicker(false);
  };

  const currentYear = currentMonth.getFullYear();
  const currentMonthNum = currentMonth.getMonth();
  const months = [t.january || 'January', t.february || 'February', t.march || 'March', t.april || 'April', t.may || 'May', t.june || 'June', t.july || 'July', t.august || 'August', t.september || 'September', t.october || 'October', t.november || 'November', t.december || 'December'];
  const years = Array.from({ length: 10 }, (_, i) => currentYear - 5 + i);

  const themes = { dark: 1, light: 2, ocean: 3, sunset: 4, forest: 5 };

  return (
    <div className="pb-10">
      {/* Header */}
      <header className="pt-12 pb-6 px-6 flex items-center justify-between sticky top-0 z-10 backdrop-blur-md bg-opacity-80 transition-colors duration-300"
              style={{ backgroundColor: 'var(--finance-header)' }}>
        <button onClick={() => setCurrentMonth(subMonths(currentMonth, 1))} className="hover:opacity-70 transition">
          <Icon name="chevron-left" size={24} />
        </button>
        
        <div className="relative">
          <button onClick={() => setShowMonthPicker(!showMonthPicker)} className="text-xl font-bold capitalize hover:opacity-70 transition">
            {yearMode ? `${selectedYear}` : format(currentMonth, 'LLLL yyyy', { locale })}
          </button>
          
          {showMonthPicker && (
            <div className="fixed inset-0 z-40" onClick={handleMonthPickerClose} />
          )}
          {showMonthPicker && (
            <div className="absolute top-16 left-1/2 transform -translate-x-1/2 z-50 bg-gradient-to-br from-blue-900/95 to-black/95 border border-blue-500/40 rounded-2xl p-6 backdrop-blur-md shadow-2xl min-w-80">
              <div className="space-y-6">
                {/* Months Grid */}
                <div>
                  <h3 className="text-sm font-bold text-blue-300 mb-3 uppercase tracking-wider">{t.monthly || 'Select Month'}</h3>
                  <div className="grid grid-cols-4 gap-2">
                    {months.map((month, idx) => (
                      <button
                        key={month}
                        onClick={() => handleMonthSelect(idx)}
                        className={cn(
                          "px-3 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 transform hover:scale-105",
                          !yearMode && currentMonth.getFullYear() === selectedYear && currentMonthNum === idx
                            ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/50"
                            : "bg-white/10 opacity-70 hover:bg-white/20 hover:opacity-100 text-white"
                        )}
                      >
                        {month.substring(0, 3).toUpperCase()}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                
                {/* Years Grid */}
                <div>
                  <h3 className="text-sm font-bold text-blue-300 mb-3 uppercase tracking-wider">{t.yearly || 'Select Year'}</h3>
                  <div className="space-y-2">
                    <button
                      onClick={handleCurrentYearClick}
                      className="w-full px-3 py-2.5 rounded-lg text-sm font-bold bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-lg shadow-purple-500/50 transition-all duration-200 transform hover:scale-105"
                    >
                      📅 {t.currentYear || 'THIS YEAR'} ({currentYear})
                    </button>
                    <div className="grid grid-cols-5 gap-2">
                      {years.map((year) => (
                        <button
                          key={year}
                          onClick={() => handleYearSelect(year)}
                          className={cn(
                            "px-2 py-2 rounded-lg text-sm font-semibold transition-all duration-200 transform hover:scale-105",
                            selectedYear === year && !yearMode
                              ? "bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg shadow-green-500/50"
                              : "bg-white/10 opacity-70 hover:bg-white/20 hover:opacity-100 text-white"
                          )}
                        >
                          {year}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <button onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} className="hover:opacity-70 transition">
          <Icon name="chevron-right" size={24} />
        </button>
      </header>

      <div className="px-6 flex justify-between items-center mb-4 gap-2">
        {lastDeletedTx && (
          <button 
            onClick={undoLastTransaction} 
            className="p-2 rounded-full bg-blue-500/20 hover:bg-blue-500/30 transition text-blue-400 text-xs font-semibold animate-pulse"
            title={t.undo}
          >
            ↶ {t.undo}
          </button>
        )}
        <button onClick={() => setShowSearch(!showSearch)} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition" title="Search">
           <Icon name="search" size={20} />
        </button>

        <div className="flex gap-2">
          <div className="relative group">
            <button className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition flex items-center justify-center">
              <Icon name="globe" size={18} />
            </button>
            <div className="absolute right-0 top-12 bg-black/90 border border-white/20 rounded-lg p-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 grid grid-cols-3 gap-1 w-32">
              {['bg', 'en', 'ru', 'de', 'fr', 'es', 'it', 'pt', 'pl', 'nl', 'sv', 'da', 'tr', 'el', 'cs', 'sk', 'hu', 'ro'].map((l) => (
                <button 
                  key={l} 
                  onClick={() => setLanguage(l as any)}
                  className={cn("px-2 py-1 rounded text-[10px] transition text-center", language === l ? "bg-white/30 font-bold" : "opacity-60 hover:opacity-100")}
                >
                  {l.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
          <button onClick={toggleTheme} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition"><Icon name="palette" size={18} /></button>
          <button onClick={exportData} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition"><Icon name="download" size={18} /></button>
          <label className="p-2 rounded-full bg-white/10 hover:bg-white/20 cursor-pointer transition">
            <Icon name="upload" size={18} />
            <input type="file" accept=".json" onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              try {
                const text = await file.text();
                const data = JSON.parse(text);
                if (data.transactions && Array.isArray(data.transactions)) {
                  setTransactions(data.transactions);
                  setRecurringTx(data.recurringTx || []);
                  setBudgets(data.budgets || {});
                  setCustomCategories(data.customCategories || []);
                  alert('✅ Data imported!');
                } else {
                  alert('❌ Invalid format');
                }
              } catch (err) {
                alert('❌ Error: ' + (err as any).message);
              }
            }} className="hidden" />
          </label>
        </div>
      </div>

      {showSearch && (
        <div className="px-6 mb-4 space-y-3">
          <div className="space-y-2">
            <p className="text-xs opacity-60">🔍 {t.search}</p>
            <Input 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="bg-white/10 border-none text-white placeholder:text-white/50 text-sm"
            />
            <p className="text-[10px] opacity-50">Examples: "pizza", "food", "50"</p>
          </div>
        </div>
      )}

      <div className="px-4 space-y-3 pb-24">
        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-2">
          <div className="p-3 rounded-xl bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/30 backdrop-blur">
            <p className="text-[9px] opacity-70 mb-1">{t.incomeTitle}</p>
            <h3 className="text-sm font-bold text-green-400">{income.toFixed(0)}</h3>
          </div>
          <div className="p-3 rounded-xl bg-gradient-to-br from-red-500/20 to-red-600/10 border border-red-500/30 backdrop-blur">
            <p className="text-[9px] opacity-70 mb-1">{t.expenses}</p>
            <h3 className="text-sm font-bold text-red-400">{expense.toFixed(0)}</h3>
          </div>
          <div className="p-3 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/10 border border-cyan-500/30 backdrop-blur">
            <p className="text-[9px] opacity-70 mb-1">{t.balance}</p>
            <h3 className={cn("text-sm font-bold", balance >= 0 ? "text-cyan-400" : "text-red-400")}>{balance.toFixed(0)}</h3>
          </div>
        </div>

        {/* Main Balance */}
        <div className="text-center p-4 rounded-2xl bg-white/5 border border-white/5">
          <p className="text-xs opacity-70 mb-1">{t.balance}</p>
          <h1 className="text-4xl font-bold tracking-tight">
            {balance.toFixed(2)} <span className="text-lg align-top opacity-50">{currency}</span>
          </h1>
        </div>

        {/* Pie Charts - Expenses and Income Side by Side */}
        <div className="grid grid-cols-2 gap-2 h-[200px]">
          {/* Expenses Chart */}
          <div className="relative">
            {chartData.length > 0 ? (
              <>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      innerRadius={35}
                      outerRadius={55}
                      paddingAngle={3}
                      dataKey="value"
                      stroke="none"
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-[9px] font-bold opacity-70 text-center">{t.expenses}</p>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full opacity-30 text-[10px]">{t.noExpenses}</div>
            )}
          </div>

          {/* Income Chart */}
          <div className="relative">
            {incomeChartData.length > 0 ? (
              <>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={incomeChartData}
                      innerRadius={35}
                      outerRadius={55}
                      paddingAngle={3}
                      dataKey="value"
                      stroke="none"
                    >
                      {incomeChartData.map((entry, index) => (
                        <Cell key={`income-cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-[9px] font-bold opacity-70 text-center">{t.incomeTitle}</p>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full opacity-30 text-[10px]">{t.noFrequentIncome}</div>
            )}
          </div>
        </div>

        {/* Quick Categories Carousel with Quick Add Buttons */}
        <div className="space-y-2">
          {/* Categories Row */}
          <div className="flex overflow-x-auto no-scrollbar gap-2 pb-1">
            {displayQuickCategories.map(key => {
               const cat = allCategories[key];
               if (!cat) return null;
               const isIncome = incomeCategories[language][key] !== undefined;
               
               return (
                 <button
                   key={key}
                   onClick={() => openAdd(key, isIncome)}
                   className="flex flex-col items-center gap-0.5 shrink-0 w-[55px]"
                 >
                   <div 
                     className="w-[45px] h-[45px] rounded-lg flex items-center justify-center active:scale-95 transition shadow-lg border border-white/10"
                     style={{ backgroundColor: cat.color }}
                   >
                     <Icon name={cat.icon} size={20} color="white" />
                   </div>
                   <span className="text-[8px] opacity-70 truncate w-full text-center">{cat.name}</span>
                 </button>
               );
            })}
          </div>

          {/* Quick Add Buttons - Bottom Right */}
          <div className="flex gap-2 justify-end">
            <button 
              onClick={() => openAdd(undefined, true)}
              className="py-1.5 px-3 rounded-lg bg-green-500/20 text-green-400 font-bold text-[11px] active:scale-95 transition border border-green-500/30 flex items-center justify-center gap-1"
              data-testid="button-add-income"
            >
              <Icon name="plus" size={14} />
              {t.incomeTitle}
            </button>
            <button 
              onClick={() => openAdd(undefined, false)}
              className="py-1.5 px-3 rounded-lg bg-red-500/20 text-red-400 font-bold text-[11px] active:scale-95 transition border border-red-500/30 flex items-center justify-center gap-1"
              data-testid="button-add-expense"
            >
              <Icon name="plus" size={14} />
              {t.expenses}
            </button>
          </div>
        </div>

        {/* Period & Sort Controls */}
        <div className="px-0 space-y-2">
          <div className="flex gap-1 flex-wrap">
            {['month', 'week', 'all'].map(p => (
              <button
                key={p}
                onClick={() => { setPeriodFilter(p as any); }}
                className={cn("px-2 py-1 text-xs rounded transition-colors", 
                  periodFilter === p ? "bg-white/20" : "bg-white/5 opacity-50"
                )}
              >
                {p === 'month' ? t.month : p === 'week' ? t.week : t.all}
              </button>
            ))}
            <button
              onClick={() => setPeriodFilter('custom')}
              className={cn("px-2 py-1 text-xs rounded transition-colors", 
                periodFilter === 'custom' ? "bg-white/20" : "bg-white/5 opacity-50"
              )}
            >
              {t.custom}
            </button>
          </div>

          {periodFilter === 'custom' && (
            <div className="space-y-1.5 p-2 bg-white/5 rounded-lg border border-white/5">
              <p className="text-[10px] opacity-70 font-semibold">{t.dateRange}</p>
              <div className="flex gap-2">
                <Input 
                  type="date"
                  value={customDateFrom}
                  onChange={(e) => setCustomDateFrom(e.target.value)}
                  className="flex-1 bg-white/10 border-none text-white text-xs"
                />
                <span className="flex items-center opacity-50">{t.to}</span>
                <Input 
                  type="date"
                  value={customDateTo}
                  onChange={(e) => setCustomDateTo(e.target.value)}
                  className="flex-1 bg-white/10 border-none text-white text-xs"
                />
              </div>
            </div>
          )}
        </div>

        <div className="px-0 flex justify-end">
          {/* Sort */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="text-xs opacity-50 flex items-center gap-1 px-2 py-1 bg-white/5 rounded hover:bg-white/10 transition">
                <Icon name="sort" size={14} />
                {sortBy.includes('date') ? t.sortDate : t.sortAmount} {sortBy.includes('asc') ? '↑' : '↓'}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40 bg-zinc-900 border-zinc-800 text-white">
              <DropdownMenuItem onClick={() => setSortBy('date-desc')} className="cursor-pointer"><Icon name="arrow-down" size={14} className="mr-2" /> {t.dateNewest}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('date-asc')} className="cursor-pointer"><Icon name="arrow-up" size={14} className="mr-2" /> {t.dateOldest}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('amount-desc')} className="cursor-pointer"><Icon name="arrow-down" size={14} className="mr-2" /> {t.amountHigh}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('amount-asc')} className="cursor-pointer"><Icon name="arrow-up" size={14} className="mr-2" /> {t.amountLow}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Recent Transactions */}
        <div className="pb-20">
          <h3 className="text-sm font-bold opacity-50 mb-3">{t.allTransactions}</h3>
          {displayTransactions.length === 0 && (
            <div className="text-center py-8 opacity-30 italic">{t.noExpenses}</div>
          )}
          <div className="space-y-2">
            {displayTransactions.map(tx => {
              const cat = tx.income 
                ? incomeCategories[language][tx.categoryKey] 
                : expenseCategories[language][tx.categoryKey];
              
              return (
                <div key={tx.id} className="flex items-center justify-between p-3 rounded-xl backdrop-blur-sm bg-white/5 border border-white/5 hover:bg-white/8 transition-colors">
                  <div className="flex items-center gap-3 flex-1">
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center text-white shadow-lg"
                      style={{ backgroundColor: cat?.color || '#555' }}
                    >
                      <Icon name={cat?.icon} size={18} color="white" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{cat?.name || tx.categoryKey}</p>
                      <p className="text-xs opacity-50">
                        {format(parseISO(tx.date), 'd MMM', { locale })} 
                        {tx.note && ` • ${tx.note}`}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={cn("font-bold", tx.income ? "text-green-400" : "text-white")}>
                      {tx.income ? '+' : '-'}{tx.amount.toFixed(2)}
                    </span>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="p-1 hover:bg-white/10 rounded opacity-60 hover:opacity-100 transition">
                          <Icon name="more-vertical" size={16} />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-40 bg-zinc-900 border-zinc-800 text-white">
                        <DropdownMenuItem onClick={() => handleEdit(tx)} className="cursor-pointer"><Icon name="edit" size={14} className="mr-2" /> {t.editTransaction}</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => deleteTransaction(tx.id)} className="text-red-500 cursor-pointer"><Icon name="trash" size={14} className="mr-2" /> {t.delete}</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <AddTransactionDialog 
        open={isAddOpen} 
        onOpenChange={setIsAddOpen} 
        preselectedCategory={selectedCategory}
        isIncome={isIncomeModal}
        editTransaction={editingTx}
      />
    </div>
  );
}
