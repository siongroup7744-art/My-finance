import { useState } from 'react';
import { useFinance } from '@/lib/finance-context';
import { verifyPassword } from '@/lib/password-utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function Login() {
  const { setPassword, hasPassword } = useFinance();
  const [password, setPasswordInput] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [mode, setMode] = useState<'login' | 'setup' | 'choice'>(!hasPassword ? 'choice' : 'login');

  const handleSkipPassword = () => {
    sessionStorage.setItem('isAuthenticated', 'true');
    window.location.reload();
  };

  const handleSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!password) {
      setError('Please enter a password');
      return;
    }
    if (password.length < 4) {
      setError('Password must be at least 4 characters');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setIsLoading(true);
    try {
      await setPassword(password);
      sessionStorage.setItem('isAuthenticated', 'true');
      window.location.reload();
    } catch (err) {
      setError('Error setting password');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!password) {
      setError('Please enter your password');
      return;
    }

    setIsLoading(true);
    try {
      const passwordHash = localStorage.getItem('passwordHash');
      if (!passwordHash) {
        setError('No password set');
        return;
      }

      const isValid = await verifyPassword(password, passwordHash);
      if (isValid) {
        sessionStorage.setItem('isAuthenticated', 'true');
        window.location.reload();
      } else {
        setError('Incorrect password');
        setPasswordInput('');
      }
    } catch (err) {
      setError('Error verifying password');
    } finally {
      setIsLoading(false);
    }
  };

  if (mode === 'choice') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
        <div className="w-full max-w-md">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl p-8 shadow-2xl">
            <div className="text-center mb-8">
              <div className="text-4xl mb-4">💳</div>
              <h1 className="text-3xl font-bold text-white mb-2">Finance Tracker</h1>
              <p className="text-slate-400 text-sm">
                Protect your financial data with a password (optional)
              </p>
            </div>

            <div className="space-y-4">
              <Button
                onClick={() => setMode('setup')}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 rounded-lg transition-all"
                data-testid="button-setup-password"
              >
                🔒 Set Password
              </Button>

              <Button
                onClick={handleSkipPassword}
                className="w-full bg-slate-700 hover:bg-slate-600 text-slate-200 font-medium py-3 rounded-lg transition-all"
                data-testid="button-skip-password"
              >
                ⏭️ Skip for Now
              </Button>
            </div>

            <p className="text-center text-slate-500 text-xs mt-6">
              You can set a password later in settings
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="w-full max-w-md">
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-8 shadow-2xl">
          <div className="text-center mb-8">
            <div className="text-4xl mb-4">💳</div>
            <h1 className="text-3xl font-bold text-white mb-2">Finance Tracker</h1>
            <p className="text-slate-400">
              {mode === 'setup' ? 'Create a password to protect your data' : 'Enter your password'}
            </p>
          </div>

          <form onSubmit={mode === 'setup' ? handleSetup : handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                {mode === 'setup' ? 'Set Password' : 'Password'}
              </label>
              <Input
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPasswordInput(e.target.value)}
                disabled={isLoading}
                className="w-full bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                data-testid="input-password"
              />
            </div>

            {mode === 'setup' && (
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Confirm Password
                </label>
                <Input
                  type="password"
                  placeholder="Confirm password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  disabled={isLoading}
                  className="w-full bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                  data-testid="input-confirm-password"
                />
              </div>
            )}

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/50 rounded-lg text-red-400 text-sm">
                {error}
              </div>
            )}

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg"
              data-testid="button-submit"
            >
              {isLoading ? '...' : mode === 'setup' ? 'Set Password' : 'Unlock'}
            </Button>
          </form>

          {mode === 'setup' && (
            <Button
              onClick={() => { setMode('choice'); setPasswordInput(''); setConfirmPassword(''); setError(''); }}
              className="w-full mt-3 bg-slate-700 hover:bg-slate-600 text-slate-200 font-medium py-2 rounded-lg"
              data-testid="button-back"
            >
              ← Back
            </Button>
          )}

          <p className="text-center text-slate-400 text-xs mt-6">
            🔒 Your password is stored securely using SHA-256 hashing
          </p>
        </div>
      </div>
    </div>
  );
}
