export type Transaction = {
  id: string;
  amount: number;
  categoryKey: string;
  income: boolean;
  date: string;
  note: string;
  originId?: string;
};

export type RecurringTransaction = Transaction & {
  type: 'weekly' | 'monthly' | 'yearly';
  lastApplied: string;
};

export type Category = {
  key: string;
  name: string;
  icon: string;
  color: string;
  translations?: Record<string, { name: string }>;
  income?: boolean;
};

export type Theme = {
  bg: string;
  card: string;
  header: string;
  text: string;
  sub: string;
  accent: string;
};

export type Language = 'bg' | 'en' | 'ru' | 'de' | 'fr' | 'es' | 'it' | 'pt' | 'pl' | 'nl' | 'sv' | 'da' | 'tr' | 'el' | 'cs' | 'sk' | 'hu' | 'ro';
