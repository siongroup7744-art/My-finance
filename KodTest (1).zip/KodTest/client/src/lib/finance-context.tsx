import React, { useState, useEffect, useContext, createContext } from 'react';
import { addWeeks, addMonths as addMonthsFn, addYears, parseISO, isSameDay, format } from 'date-fns';
import { themes, expenseCategories, incomeCategories } from './categories';
import { translations, currencies } from './translations';
import { Transaction, RecurringTransaction, Category, Language } from './types';

type FinanceContextType = {
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  recurringTx: RecurringTransaction[];
  setRecurringTx: React.Dispatch<React.SetStateAction<RecurringTransaction[]>>;
  budgets: Record<string, Record<string, number>>;
  setBudgets: React.Dispatch<React.SetStateAction<Record<string, Record<string, number>>>>;
  customCategories: Category[];
  setCustomCategories: React.Dispatch<React.SetStateAction<Category[]>>;
  currentMonth: Date;
  setCurrentMonth: React.Dispatch<React.SetStateAction<Date>>;
  yearMode: boolean;
  setYearMode: React.Dispatch<React.SetStateAction<boolean>>;
  selectedYear: number;
  setSelectedYear: React.Dispatch<React.SetStateAction<number>>;
  language: Language;
  setLanguage: React.Dispatch<React.SetStateAction<Language>>;
  themeKey: string;
  setThemeKey: React.Dispatch<React.SetStateAction<string>>;
  theme: any;
  exportData: () => Promise<void>;
  importData: () => Promise<void>;
  addTransaction: (tx: Omit<Transaction, 'id'>) => void;
  deleteTransaction: (id: string) => void;
  updateTransaction: (tx: Transaction) => void;
  addCategory: (cat: Category) => void;
  deleteCategory: (key: string) => void;
  updateCategory: (cat: Category) => void;
  hasPassword: boolean;
  setPassword: (password: string) => Promise<void>;
  logout: () => void;
  undoLastTransaction: () => void;
  lastDeletedTx: Transaction | null;
};

const FinanceContext = createContext<FinanceContextType | null>(null);

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (!context) throw new Error('useFinance must be used within FinanceProvider');
  return context;
};

export const FinanceProvider = ({ children }: { children: React.ReactNode }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [recurringTx, setRecurringTx] = useState<RecurringTransaction[]>([]);
  const [budgets, setBudgets] = useState<Record<string, Record<string, number>>>({});
  const [customCategories, setCustomCategories] = useState<Category[]>([]);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [yearMode, setYearMode] = useState(false);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [language, setLanguage] = useState<Language>('bg');
  const [themeKey, setThemeKey] = useState('dark');
  const [hasPassword, setHasPassword] = useState(false);
  const [lastDeletedTx, setLastDeletedTx] = useState<Transaction | null>(null);
  const [futureNotifications, setFutureNotifications] = useState<Transaction[]>([]);

  useEffect(() => {
    const load = () => {
      try {
        const storedTx = localStorage.getItem('transactions');
        const storedRec = localStorage.getItem('recurringTx');
        const storedBudgets = localStorage.getItem('budgets');
        const storedCats = localStorage.getItem('customCategories');
        const storedLang = localStorage.getItem('language');
        const storedTheme = localStorage.getItem('themeKey');
        const storedPassword = localStorage.getItem('passwordHash');

        if (storedTx) setTransactions(JSON.parse(storedTx));
        if (storedRec) setRecurringTx(JSON.parse(storedRec));
        if (storedBudgets) setBudgets(JSON.parse(storedBudgets));
        if (storedCats) setCustomCategories(JSON.parse(storedCats));
        if (storedLang) setLanguage(storedLang as Language);
        if (storedTheme) setThemeKey(storedTheme);
        if (storedPassword) setHasPassword(true);
      } catch (err) {
        console.error('Error loading data:', err);
      }
    };
    load();
  }, []);

  useEffect(() => {
    const saveToStorage = () => {
      try {
        localStorage.setItem('transactions', JSON.stringify(transactions));
        localStorage.setItem('recurringTx', JSON.stringify(recurringTx));
        localStorage.setItem('budgets', JSON.stringify(budgets));
        localStorage.setItem('customCategories', JSON.stringify(customCategories));
        localStorage.setItem('language', language);
        localStorage.setItem('themeKey', themeKey);
      } catch (err) {
        if (err instanceof Error && err.message.includes('QuotaExceededError')) {
          console.error('localStorage quota exceeded - data too large');
        }
      }
    };

    const timer = setTimeout(saveToStorage, 1000);
    return () => clearTimeout(timer);
  }, [transactions, recurringTx, budgets, customCategories, language, themeKey]);

  const theme = themes[themeKey as keyof typeof themes] || themes.dark;

  useEffect(() => {
    const root = window.document.documentElement;
    root.style.setProperty('--finance-bg', theme.bg);
    root.style.setProperty('--finance-card', theme.card);
    root.style.setProperty('--finance-text', theme.text);
    root.style.setProperty('--finance-sub', theme.sub);
    root.style.setProperty('--finance-accent', theme.accent);
    root.style.setProperty('--finance-header', theme.header);
    document.body.style.backgroundColor = theme.bg;
    document.body.style.color = theme.text;
  }, [theme]);

  useEffect(() => {
    const now = new Date();
    let hasChanges = false;
    const newTransactions = [...transactions];
    const newRecurring = [...recurringTx];
    
    const txLookupMap = new Map<string, Set<string>>();
    transactions.forEach(t => {
      if (t.originId) {
        if (!txLookupMap.has(t.originId)) {
          txLookupMap.set(t.originId, new Set());
        }
        txLookupMap.get(t.originId)!.add(t.date.split('T')[0]);
      }
    });

    recurringTx.forEach((rt, idx) => {
      if (!rt.id || !rt.type || !rt.lastApplied) return;
      let lastDate = parseISO(rt.lastApplied);
      let nextDate = lastDate;
      const originDates = txLookupMap.get(rt.id) || new Set();

      while (true) {
        if (rt.type === 'weekly') nextDate = addWeeks(lastDate, 1);
        else if (rt.type === 'monthly') nextDate = addMonthsFn(lastDate, 1);
        else if (rt.type === 'yearly') nextDate = addYears(lastDate, 1);
        else break;

        if (nextDate > now) break;

        const dateKey = nextDate.toISOString().split('T')[0];
        if (!originDates.has(dateKey)) {
          const newTx: Transaction = {
            id: Date.now().toString() + Math.random(),
            amount: rt.amount,
            categoryKey: rt.categoryKey,
            income: rt.income,
            date: nextDate.toISOString(),
            note: rt.note || '',
            originId: rt.id
          };
          newTransactions.unshift(newTx);
          originDates.add(dateKey);
          hasChanges = true;
        }
        lastDate = nextDate;
      }

      if (lastDate > parseISO(rt.lastApplied)) {
        newRecurring[idx] = { ...rt, lastApplied: lastDate.toISOString() };
        hasChanges = true;
      }
    });

    if (hasChanges) {
      setTransactions(newTransactions);
      setRecurringTx(newRecurring);
    }
  }, [recurringTx]);

  const exportData = async () => {
    const data = { transactions, recurringTx, budgets, customCategories, language, themeKey };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'finance_backup.json';
    a.click();
  };

  const importData = async () => {
  };

  const addTransaction = (tx: Omit<Transaction, 'id'>) => {
    const newTx = { ...tx, id: Date.now().toString() + Math.random() };
    setTransactions(prev => [newTx, ...prev]);
  };

  const deleteTransaction = (id: string) => {
    const tx = transactions.find(t => t.id === id);
    if (tx) setLastDeletedTx(tx);
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  const undoLastTransaction = () => {
    if (lastDeletedTx) {
      setTransactions(prev => [lastDeletedTx, ...prev]);
      setLastDeletedTx(null);
    }
  };

  const updateTransaction = (tx: Transaction) => {
    setTransactions(prev => prev.map(t => t.id === tx.id ? tx : t));
  };

  const addCategory = (cat: Category) => {
    setCustomCategories(prev => [...prev, cat]);
  };

  const deleteCategory = (key: string) => {
    setCustomCategories(prev => prev.filter(c => c.key !== key));
  };

  const updateCategory = (cat: Category) => {
    setCustomCategories(prev => prev.map(c => c.key === cat.key ? cat : c));
  };

  const setPassword = async (password: string) => {
    const { hashPassword } = await import('./password-utils');
    const hash = await hashPassword(password);
    localStorage.setItem('passwordHash', hash);
    setHasPassword(true);
  };

  const logout = () => {
    sessionStorage.removeItem('isAuthenticated');
    window.location.reload();
  };

  return (
    <FinanceContext.Provider value={{
      transactions,
      setTransactions,
      recurringTx,
      setRecurringTx,
      budgets,
      setBudgets,
      customCategories,
      setCustomCategories,
      currentMonth,
      setCurrentMonth,
      yearMode,
      setYearMode,
      selectedYear,
      setSelectedYear,
      language,
      setLanguage,
      themeKey,
      setThemeKey,
      theme,
      exportData,
      importData,
      addTransaction,
      deleteTransaction,
      updateTransaction,
      addCategory,
      deleteCategory,
      updateCategory,
      hasPassword,
      setPassword,
      logout,
      undoLastTransaction,
      lastDeletedTx,
    }}>
      {children}
    </FinanceContext.Provider>
  );
};
