import { Transaction } from './types';

export function debounce<T extends (...args: any[]) => any>(
  func: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: NodeJS.Timeout;
  return function (...args: Parameters<T>) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func(...args), delay);
  };
}

export function createTransactionLookupSet(transactions: Transaction[]): Set<string> {
  return new Set(transactions.map(t => `${t.originId || ''}-${t.date}`));
}

export function isTransactionExists(
  originId: string,
  dateStr: string,
  lookupSet: Set<string>
): boolean {
  return lookupSet.has(`${originId}-${dateStr}`);
}
