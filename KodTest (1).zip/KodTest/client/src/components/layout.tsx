import { useFinance } from "@/lib/finance-context";
import { translations } from "@/lib/translations";
import { Link, useLocation } from "wouter";
import { Icon } from "./icon-mapper";
import { cn } from "@/lib/utils";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { language } = useFinance();
  const [location] = useLocation();
  const t = translations[language];

  const navItems = [
    { path: '/', label: t.home, icon: 'home' },
    { path: '/categories', label: t.categories, icon: 'settings' },
    { path: '/budgets', label: t.budgets, icon: 'wallet' },
    { path: '/stats', label: t.stats, icon: 'pie-chart' },
  ];

  return (
    <div className="fixed inset-0 w-full h-full transition-colors duration-300 overflow-hidden" style={{ backgroundColor: 'var(--finance-bg)', color: 'var(--finance-text)' }}>
      <div className="mx-auto max-w-md h-full flex flex-col relative shadow-2xl overflow-hidden bg-inherit">
        <div className="flex-1 overflow-y-auto pb-24 no-scrollbar scroll-smooth overscroll-contain">
          {children}
        </div>

        {/* Bottom Navigation */}
        <nav className="absolute bottom-0 left-0 right-0 h-20 border-t border-white/5 px-6 flex items-center justify-around backdrop-blur-xl transition-colors duration-300"
             style={{ backgroundColor: 'var(--finance-header)' }}>
          {navItems.map((item) => {
            const isActive = location === item.path;
            return (
              <Link key={item.path} href={item.path}>
                <div className={cn(
                  "flex flex-col items-center justify-center gap-1 transition-all duration-200 cursor-pointer",
                  isActive ? "opacity-100 scale-110" : "opacity-50 hover:opacity-80"
                )}>
                  <Icon 
                    name={item.icon} 
                    size={24} 
                    color={isActive ? 'var(--finance-accent)' : 'var(--finance-text)'} 
                  />
                  <span className="text-[10px] font-medium" style={{ color: isActive ? 'var(--finance-accent)' : 'var(--finance-text)' }}>
                    {item.label}
                  </span>
                </div>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
