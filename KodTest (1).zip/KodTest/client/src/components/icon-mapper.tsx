import { 
  Utensils, Coffee, Car, CarTaxiFront, Receipt, Wifi, ShoppingCart, Shirt, Pill, Heart, 
  Gamepad2, Film, Gift, Dumbbell, Book, MoreHorizontal, Banknote, Briefcase, TrendingUp, 
  PlusCircle, Home, PieChart, Wallet, Settings, Plus, Trash2, Edit, Calendar, Search,
  ChevronLeft, ChevronRight, Download, Upload, Palette, Globe, MoreVertical, LucideIcon,
  ArrowUp, ArrowDown, TrendingDown
} from 'lucide-react';

export const iconMap: Record<string, React.ComponentType<{ size?: number; color?: string; className?: string }>> = {
  utensils: Utensils,
  coffee: Coffee,
  car: Car,
  'car-taxi-front': CarTaxiFront,
  receipt: Receipt,
  wifi: Wifi,
  'shopping-cart': ShoppingCart,
  shirt: Shirt,
  pill: Pill,
  heart: Heart,
  'gamepad-2': Gamepad2,
  film: Film,
  gift: Gift,
  dumbbell: Dumbbell,
  book: Book,
  'more-horizontal': MoreHorizontal,
  banknote: Banknote,
  briefcase: Briefcase,
  'trending-up': TrendingUp,
  'plus-circle': PlusCircle,
  home: Home,
  'pie-chart': PieChart,
  wallet: Wallet,
  settings: Settings,
  plus: Plus,
  trash: Trash2,
  edit: Edit,
  calendar: Calendar,
  search: Search,
  'chevron-left': ChevronLeft,
  'chevron-right': ChevronRight,
  download: Download,
  upload: Upload,
  palette: Palette,
  globe: Globe,
  'more-vertical': MoreVertical,
  'arrow-up': ArrowUp,
  'arrow-down': ArrowDown,
  'trending-down': TrendingDown
};

export const Icon = ({ name, size = 24, color = 'currentColor', className }: { name: string, size?: number, color?: string, className?: string }) => {
  const LucideIcon = iconMap[name] || MoreHorizontal;
  return <LucideIcon size={size} color={color} className={className} />;
};
