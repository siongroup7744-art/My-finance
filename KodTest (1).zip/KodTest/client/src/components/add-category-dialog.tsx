import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useFinance } from "@/lib/finance-context";
import { translations } from "@/lib/translations";
import { Icon, iconMap } from "./icon-mapper";
import { cn } from "@/lib/utils";
import { Category } from "@/lib/types";

interface AddCategoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editCategory?: Category;
}

export default function AddCategoryDialog({ open, onOpenChange, editCategory }: AddCategoryDialogProps) {
  const { language, addCategory, updateCategory } = useFinance();
  const t = translations[language];
  
  const [name, setName] = useState(editCategory?.name || "");
  const [icon, setIcon] = useState(editCategory?.icon || "star");
  const [color, setColor] = useState(editCategory?.color || "#FF6B6B");
  const [isIncome, setIsIncome] = useState(editCategory?.income || false);

  // Reset when opening for edit or new
  useEffect(() => {
    if (open) {
      if (editCategory) {
        setName(editCategory.name);
        setIcon(editCategory.icon);
        setColor(editCategory.color);
        setIsIncome(editCategory.income || false);
      } else {
        setName("");
        setIcon("star");
        setColor("#FF6B6B");
        setIsIncome(false);
      }
    }
  }, [open, editCategory]);

  const colors = ['#FF6B6B','#D35400','#4ECDC4','#1ABC9C','#96CEB4','#3498DB','#FECA57','#9B59B6','#FF9FF3','#E91E63','#45B7D1','#34495E','#E67E22','#2ECC71','#F1C40F','#95A5A6'];
  const icons = Object.keys(iconMap);

  const handleSubmit = () => {
    if (!name) return;
    
    const catData: Category = {
      key: editCategory?.key || `custom_${Date.now()}`,
      name,
      icon,
      color,
      income: isIncome,
      translations: {
        bg: { name },
        en: { name },
        ru: { name }
      }
    };

    if (editCategory) {
      updateCategory(catData);
    } else {
      addCategory(catData);
    }
    
    setName("");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] border-none text-white max-h-[90vh] overflow-y-auto flex flex-col" style={{ backgroundColor: 'var(--finance-card)' }}>
        <DialogHeader className="sticky top-0">
          <DialogTitle className="text-center text-xl" style={{ color: 'var(--finance-text)' }}>
            {editCategory ? `Edit: ${editCategory.name}` : t.addCategory}
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-6 py-4 overflow-y-auto flex-1">
          <div className="flex justify-center gap-4">
             <Button 
              variant="ghost" 
              onClick={() => setIsIncome(false)}
              className={cn("rounded-full", !isIncome ? "bg-red-500/20 text-red-500" : "text-gray-500")}
            >
              {t.expenses}
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => setIsIncome(true)}
              className={cn("rounded-full", isIncome ? "bg-green-500/20 text-green-500" : "text-gray-500")}
            >
              {t.incomeTitle}
            </Button>
          </div>

          <div className="space-y-2">
            <label className="text-xs opacity-70">{t.categories}</label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Name"
              className="bg-black/20 border-none"
              style={{ color: 'var(--finance-text)' }}
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs opacity-70">Color</label>
            <div className="flex flex-wrap gap-2 p-2 bg-black/10 rounded-lg">
              {colors.map(c => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={cn("w-8 h-8 rounded-full transition-transform border border-white/10", color === c ? "scale-110 ring-2 ring-white" : "")}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs opacity-70">Icon</label>
            <div className="grid grid-cols-6 gap-2 h-32 overflow-y-auto p-2 bg-black/10 rounded-lg">
              {icons.map(i => (
                <button
                  key={i}
                  onClick={() => setIcon(i)}
                  className={cn("flex items-center justify-center p-2 rounded", icon === i ? "bg-white/20" : "")}
                >
                  <Icon name={i} size={20} color={icon === i ? 'white' : 'gray'} />
                </button>
              ))}
            </div>
          </div>

          <Button 
            onClick={handleSubmit} 
            className="w-full h-12 rounded-xl text-lg font-semibold sticky bottom-0"
            style={{ backgroundColor: 'var(--finance-accent)', color: '#fff' }}
          >
            {t.save}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
