import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useFinance } from "@/lib/finance-context";
import { translations } from "@/lib/translations";
import { Icon } from "./icon-mapper";
import { expenseCategories, incomeCategories } from "@/lib/categories";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

interface AddTransactionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preselectedCategory?: string;
  isIncome?: boolean;
  editTransaction?: { id: string; amount: number; note: string; date: string; categoryKey: string; income: boolean };
}

export default function AddTransactionDialog({ open, onOpenChange, preselectedCategory, isIncome = false, editTransaction }: AddTransactionDialogProps) {
  const { language, addTransaction, updateTransaction, customCategories } = useFinance();
  const t = translations[language];
  
  const [amount, setAmount] = useState(editTransaction?.amount.toString() || "");
  const [note, setNote] = useState(editTransaction?.note || "");
  const [date, setDate] = useState(editTransaction?.date ? new Date(editTransaction.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState(editTransaction?.categoryKey || preselectedCategory);
  const [type, setType] = useState<'expense' | 'income'>(editTransaction ? (editTransaction.income ? 'income' : 'expense') : (isIncome ? 'income' : 'expense'));
  const [recurring, setRecurring] = useState<'none' | 'monthly' | 'yearly' | undefined>();

  // Reset state when opening/closing or changing edit target
  useEffect(() => {
    if (open) {
      if (editTransaction) {
        setAmount(editTransaction.amount.toString());
        setNote(editTransaction.note);
        setDate(new Date(editTransaction.date).toISOString().split('T')[0]);
        setCategory(editTransaction.categoryKey);
        setType(editTransaction.income ? 'income' : 'expense');
        setRecurring(undefined);
      } else {
        setAmount("");
        setNote("");
        setDate(new Date().toISOString().split('T')[0]);
        setCategory(preselectedCategory);
        setType(isIncome ? 'income' : 'expense');
        setRecurring(undefined);
      }
    }
  }, [open, editTransaction, preselectedCategory, isIncome]);

  const handleSubmit = () => {
    const parsedAmount = parseFloat(amount);
    if (!amount || !category) {
      alert(t.selectCategory || 'Please select a category');
      return;
    }
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      alert(t.invalidAmount || 'Invalid amount');
      return;
    }
    if (!date) {
      alert(t.invalidDate || 'Invalid date');
      return;
    }
    
    const txDate = new Date(date);
    const now = new Date();
    const isFuture = txDate > now;
    
    if (isFuture) {
      const confirmed = window.confirm((t.futureTransaction || 'Future transaction') + '? ' + format(txDate, 'yyyy-MM-dd'));
      if (!confirmed) return;
    }
    
    const txData = {
      amount: parsedAmount,
      categoryKey: category,
      income: type === 'income',
      date: new Date(date).toISOString(),
      note
    };

    if (editTransaction) {
      updateTransaction({ ...txData, id: editTransaction.id });
    } else {
      addTransaction(txData);
    }
    
    onOpenChange(false);
  };

  // Combine default and custom categories
  let categories = type === 'income' ? incomeCategories[language] : expenseCategories[language];
  
  // Merge with custom categories
  const customCats = customCategories.filter(c => !!c.income === (type === 'income'));
  const mergedCategories: any = { ...categories };
  customCats.forEach(cat => {
    mergedCategories[cat.key] = cat;
  });
  categories = mergedCategories;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] border-none text-white max-h-[90vh] overflow-y-auto flex flex-col animate-in fade-in duration-200" style={{ backgroundColor: 'var(--finance-card)' }}>
        <DialogHeader className="sticky top-0">
          <DialogTitle className="text-center text-xl" style={{ color: 'var(--finance-text)' }}>
            {type === 'income' ? t.addIncome : t.addExpense}
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-6 py-4 overflow-y-auto flex-1 animate-in slide-in-from-top duration-300">
          <div className="flex justify-center gap-4">
            <Button 
              variant="ghost" 
              onClick={() => setType('expense')}
              className={cn("rounded-full", type === 'expense' ? "bg-red-500/20 text-red-500" : "text-gray-500")}
            >
              {t.expenses}
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => setType('income')}
              className={cn("rounded-full", type === 'income' ? "bg-green-500/20 text-green-500" : "text-gray-500")}
            >
              {t.incomeTitle}
            </Button>
          </div>

          <div className="flex justify-center">
            <div className="relative w-full max-w-[200px] animate-in scale-in duration-300">
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="text-center text-4xl border-none bg-transparent focus-visible:ring-0 h-20 font-bold placeholder:text-white/20 transition-all"
                style={{ color: 'var(--finance-text)' }}
                autoFocus
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs opacity-70">{t.categories}</label>
            <div className="grid grid-cols-5 gap-2 max-h-[220px] overflow-y-auto p-2 bg-black/10 rounded-lg border border-white/5">
              {Object.entries(categories).map(([key, cat]) => (
                <button
                  key={key}
                  onClick={() => setCategory(key)}
                  className={cn(
                    "flex flex-col items-center justify-center p-2 rounded-lg gap-1 transition-all",
                    category === key ? "bg-white/20 ring-2 ring-white" : "hover:bg-white/5"
                  )}
                  title={cat.name}
                >
                  <div 
                    className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: cat.color }}
                  >
                    <Icon name={cat.icon} size={16} color="white" />
                  </div>
                  <span className="text-[8px] truncate w-full text-center" style={{ color: 'var(--finance-text)' }}>
                    {cat.name}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <Input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="bg-black/20 border-none text-center"
            style={{ color: 'var(--finance-text)' }}
          />

          <Textarea
            placeholder={t.note}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="bg-black/20 border-none resize-none"
            style={{ color: 'var(--finance-text)' }}
          />

          {/* Recurring Transaction Options */}
          <div className="flex justify-center gap-2 pb-2">
             <button 
               className={cn("px-3 py-1 rounded-full text-xs border border-white/10 transition-colors", !recurring ? "bg-white/20" : "opacity-50")}
               onClick={() => setRecurring(undefined)}
               data-testid="button-recurring-once"
             >
               {t.once || 'Once'}
             </button>
             <button 
               className={cn("px-3 py-1 rounded-full text-xs border border-white/10 transition-colors", recurring === 'monthly' ? "bg-white/20" : "opacity-50")}
               onClick={() => setRecurring('monthly')}
               data-testid="button-recurring-monthly"
             >
               {t.monthly}
             </button>
             <button 
               className={cn("px-3 py-1 rounded-full text-xs border border-white/10 transition-colors", recurring === 'yearly' ? "bg-white/20" : "opacity-50")}
               onClick={() => setRecurring('yearly')}
               data-testid="button-recurring-yearly"
             >
               {t.yearly}
             </button>
          </div>

          <Button 
            onClick={handleSubmit} 
            className="w-full h-12 rounded-xl text-lg font-semibold sticky bottom-0 mt-6"
            style={{ backgroundColor: 'var(--finance-accent)', color: '#fff' }}
          >
            {t.save}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
